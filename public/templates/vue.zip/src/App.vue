<script setup></script>

<template>
  <router-view />
  <app-grid-col />
</template>
