<script setup></script>

<template>
  <slot />
</template>
