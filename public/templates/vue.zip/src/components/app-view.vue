<template>
  <div class="app-view">
    <slot />
  </div>
</template>
