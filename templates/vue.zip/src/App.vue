<script setup></script>

<template>
  <router-view />
</template>
