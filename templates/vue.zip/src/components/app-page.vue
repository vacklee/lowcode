<template>
  <div class="app-page">
    <slot />
  </div>
</template>
